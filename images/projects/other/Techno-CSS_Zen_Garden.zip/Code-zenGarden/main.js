// Create the image container
const imageContainer = document.createElement('div');
const image = document.createElement('img');
image.width = 400;

// Apply CSS styles to the image container
imageContainer.style.marginTop = '80px';

// Get the h1, h2, and h3 elements
const h1 = document.querySelector('h1');
const h2 = document.querySelector('h2');
const h3List = document.querySelectorAll('h3:not(.sidebar h3)');
const summary = document.querySelector('.summary');

// Insert the image container between h1 and h2
h1.parentNode.insertBefore(imageContainer, h2);

// Append the image to the container
imageContainer.appendChild(image);

// Set the initial image source
image.src = '../Code-zenGarden/Assets/circles/1.svg';

// Variables to track the active elements
let activeH2 = h2;
let activeH3 = null;

// Set the initial color of the active H2 element
activeH2.style.color = '#42FA3E';

// Function to handle H2 click
function handleH2Click() {
  if (activeH2 === h2) {
    if (window.innerWidth >= 1312) {
      showSummary(h2);
    }
  } else {
    hideSummary();
    showSummary(h2);
    image.src = '../Code-zenGarden/Assets/circles/1.svg';
  }
}

// Function to handle H3 click
function handleH3Click(h3, index) {
  if (activeH3 === h3) {
    return;
  }

  hideSummary();

  const div = h3.parentNode;
  const paragraphs = div.querySelectorAll('p');
  paragraphs.forEach(p => {
    p.style.display = 'block';
    p.style.animation = 'unfold 0.3s ease-in-out forwards';
  });

  activeH3 = h3;
  activeH3.style.color = '#42FA3E';
  activeH2 = null;
  h2.style.color = '';
  image.src = `../Code-zenGarden/Assets/circles/${index + 2}.svg`;
}

// Add event listeners for H2 and H3 clicks
h2.addEventListener('click', handleH2Click);
h3List.forEach((h3, index) => {
  h3.addEventListener('click', () => handleH3Click(h3, index));
});

// Event handler functions
function showSummary(element) {
  element.style.color = '#42FA3E';
  summary.style.display = 'block';
}

function hideSummary() {
  if (activeH2) {
    if (activeH2 === h2) {
      activeH2.style.color = '';
    }
    activeH2 = null;
  }
  if (activeH3) {
    activeH3.style.color = '';
    const div = activeH3.parentNode;
    const paragraphs = div.querySelectorAll('p');
    paragraphs.forEach(p => {
      p.style.display = 'none';
      p.style.animation = '';
    });
    activeH3 = null;
  }
  summary.style.display = 'none';
  image.src = '';
}

// Add event listener for window resize
window.addEventListener('resize', handleWindowSize);

// Handle window size change
function handleWindowSize() {
  const windowWidth = window.innerWidth || document.documentElement.clientWidth;

  if (windowWidth >= 1312) {
    imageContainer.style.marginTop = '136px';
    imageContainer.style.marginLeft = '80px';
    image.width = 528;
    imageContainer.style.textAlign = '';
  } else {
    imageContainer.style.marginTop = '80px';
    imageContainer.style.marginLeft = '';
    image.width = 400;
    imageContainer.style.textAlign = 'center';
  }
}

// Handle window size on page load
handleWindowSize();